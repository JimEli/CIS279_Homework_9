import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/***************************************************************
 * Model class used to hold MySQL employee data.
 **************************************************************/
public class Employee {
  private Integer employeeId;
  private String lastName;
  private Integer jobCode;
  private Integer deptCode;
  private String salary;
  // firstName made StringProperty to support tableview cell editing.
  private final StringProperty firstName = new SimpleStringProperty( this, "firstName", null );

  // Constructor.
  public Employee( 
    Integer id,
    String fName, 
    String lName,
    Integer jCode,
    Integer dCode,
    Double pay
  ) {
    employeeId = id;
    // Capitalize names.
    fName = EmployeeTableViewUtility.toTitleCase( fName );
    lName = EmployeeTableViewUtility.toTitleCase( lName );
    // Note, fName field is a StringProperty.
    firstName.set( fName ); 
    lastName = lName;
    jobCode = jCode;
    deptCode = dCode;
    salary = String.format( "$%.2f", pay ); // Format as $USD.
  }

  // Getters.
  public Integer getEmployeeId() { return employeeId; }
  public String getLastName() { return lastName; }
  public Integer getJobCode() { return jobCode; }
  public Integer getDeptCode() { return deptCode; }
  public String getSalary() { return salary; }

  // Setters.
  public void setEmployeeId( Integer id ) { employeeId = id; }
  public void setLastName( String name ) { lastName = name; }
  public void setJobCode( Integer code ) { jobCode = code;  }
  public void setDeptCode( Integer code ) { deptCode = code;  }

  // firstName Property 
  public final String getFirstName() {
    return firstName.get();
  }
  public final void setFirstName( String fName ) {
    firstNameProperty().set( fName );
  }
  public final StringProperty firstNameProperty() {
    return firstName;
  }

  // Non-class member getters.
  public final String getJobDescription() {
    // Return textual description only, skipping first five characters.
    return EmployeeTableViewUtility.toTitleCase( EmployeeTableViewUtility.getJobDescription( jobCode ).substring( 4 ) );
  }

}
